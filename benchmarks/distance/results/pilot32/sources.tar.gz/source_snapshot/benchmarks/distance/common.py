"""Shared paths and evidence I/O; mathematical checks come from the verifier."""

import hashlib
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "research" / "kit"))
sys.path.insert(0, str(ROOT / "verify"))


def atomic_json(path, value):
    """Persist complete JSON before making it visible to a reader."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def sha256(path):
    """Hash the bytes of a pinned input or executable."""
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def matrix_hash(hx, hz):
    """Hash shape and binary matrix contents, independent of file compression."""
    digest = hashlib.sha256()
    for matrix in (hx, hz):
        digest.update(str(matrix.shape).encode())
        digest.update(matrix.astype("uint8").tobytes())
    return digest.hexdigest()
